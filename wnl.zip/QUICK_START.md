# QUICK START - Claude Code Setup

## What's in this folder:
- `index.html` - Current working site
- `images/` - All 19 brand logos
- `CLAUDE_CODE_HANDOFF.md` - Full context document
- `README.md` - Deployment instructions

## Steps to start in Claude Code:

### 1. Download Claude Code
- Go to https://claude.ai/download
- Install for your OS
- Sign in with your Claude account

### 2. Set up your project folder
- Download this entire folder
- Put it somewhere like `Desktop/jackmorello-site` or `~/jackmorello-site`

### 3. Start Claude Code
- Open Claude Code
- Point it to the folder you just created
- Start a new conversation

### 4. Paste this into Claude Code:

```
I have a marketing portfolio site for Jack Morello that needs video integration and enhancement.

Current site is in index.html - it has:
- Space travel background
- Brand marquee
- Company cards
- All brand logos in images/ folder

Please read CLAUDE_CODE_HANDOFF.md for full context.

Primary goal: Add professional video integration for:
- Campaign case studies
- CRIBS.FUN demo
- Background/hero videos
- Campaign highlight reels

Also need:
- Enhanced space background (multiple star layers, subtle effects)
- Better animations
- Performance optimization

Make this production-quality for Director/VP-level marketing roles at Disney, Netflix, EA.
```

### 5. Gather your videos
Before starting, have ready:
- BMW campaign work
- Brand spots
- CRIBS.FUN demo/gameplay
- Any other campaign footage

Put video files in a `videos/` folder in your project directory, or use YouTube/Vimeo embeds.

## That's it!
Claude Code will have all the context from CLAUDE_CODE_HANDOFF.md and can build on what we already have.
