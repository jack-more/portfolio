# Jack Morello Portfolio Site - Claude Code Handoff

## PROJECT BRIEF
Build a production-grade marketing portfolio website for Jack Morello - a senior marketing executive targeting Director/VP roles at major studios (Disney, Netflix, EA, etc).

## ABOUT JACK
- 8 years marketing experience
- Led Devolved AI marketing to $100M valuation on Polygon
- Managed $1B+ in media spend at iHeartMedia and EPK.tv
- Major brand campaigns: Netflix, Disney+, Starbucks, Toyota, Sony Pictures, Prime Video, Peacock, Universal, Starzplay
- Creative work: X/Twitter brand voice, BMW Instagram, LG Mobile, Hint Water
- Currently building CRIBS.FUN (real estate price guessing game)
- Based in Los Angeles
- Contact: jaidanmorello@gmail.com, linkedin.com/in/jackmorello

## DESIGN DIRECTION
**CRITICAL:** Jack HATES corporate buzzwords and AI-sounding language. Everything should sound authentic and results-focused.

**Visual Style:**
- Space travel theme (stars shooting forward through black space)
- Clean, executive-level sophistication 
- NOT gimmicky - this is for serious roles at major companies
- Inter font family (300, 400, 500, 600, 700 weights)
- Color scheme: Deep black background (#000000), blue accents (#5da9ff), white text (#ffffff, #e0e0e0, #b8b8b8)

## CURRENT SITE CONTENT

### Header
**Jack Aidan Morello**
Tagline: Marketing Leadership • Growth Strategy • Product Development

**Intro (3 paragraphs):**
Currently building CRIBS.FUN, a mobile real estate guessing game launching on iOS, Android, and web.

Previously led marketing at Devolved AI through $100M valuation on Polygon by building go-to-market strategy for their AI agent marketplace. Scaled crypto platforms including Dtravel, NEAR Tasks, and Travala through token launches, community building, and user acquisition.

Managed $1B+ in media spend at iHeartMedia and EPK.tv for major brands like Starbucks, Netflix, Disney+, and Toyota. Beyond encoding and splicing digital assets, I organize them into campaigns that maximize every advertising dollar spent.

### Section 1: Marketing Leadership
Devolved AI, Dtravel, Travala, NEAR Tasks (see full copy in index.html)

### Section 2: Paid Media at Scale
9 major brands with demographics and channels (see full copy in index.html)

### Section 3: Creative & Brand Building
X/Twitter, BMW, LG Mobile, Hint Water (see full copy in index.html)

## WHAT NEEDS TO BE ADDED

### 1. VIDEO INTEGRATION (PRIMARY GOAL)
- Hero video background option
- Case study videos showing actual campaign work
- CRIBS.FUN demo video
- Campaign highlight reels
- Responsive video players with controls
- Optimized loading

### 2. ENHANCED ANIMATIONS
- Smoother scroll animations
- Card hover effects
- Better transitions
- Subtle parallax

### 3. BETTER SPACE BACKGROUND
- Multiple star layers at different speeds
- Occasional shooting stars
- Faint nebula hints
- Keep it black and professional

### 4. PERFORMANCE OPTIMIZATION
- Lazy load images/videos
- Fast load times (< 2 seconds)
- Mobile optimization

## TONE GUIDELINES

✅ DO: Direct, metric-focused, specific results, active voice
❌ NEVER: "It's not X, it's Y" / Business buzzwords / AI patterns / Corporate speak

**Example:**
BAD: "I don't just manage campaigns; I architect growth strategies."
GOOD: "Managed $900M in media spend for Netflix, Disney+, and Toyota."

## DEPLOYMENT
Netlify/Vercel → jackmorello.com

## SUCCESS CRITERIA
Make hiring managers think: "This person has scaled real companies with real money. No BS."
