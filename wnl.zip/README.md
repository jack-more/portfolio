# Jack Morello Website - Deployment Instructions

## Folder Structure
```
jackmorello-website/
├── index.html (main website file)
└── images/ (all brand logos)
    ├── devolved.png
    ├── dtravel.jpg
    ├── near.png
    ├── travala.png
    ├── toyota.png
    ├── starbucks.png
    ├── netflix.png
    ├── disneyplus.png
    ├── prime.png
    ├── sony.png
    ├── peacock.png
    ├── universal.png
    ├── starzplay.png
    ├── bmw.png
    ├── lg.png
    ├── hint.png
    └── twitter.png
```

## Quick Deploy (RECOMMENDED)

### Option 1: Netlify Drop (Easiest - 5 minutes)
1. Go to https://app.netlify.com/drop
2. Drag the entire `jackmorello-website` folder into the drop zone
3. Wait for upload (30 seconds)
4. Netlify gives you a URL like `random-name-123.netlify.app`
5. Click "Domain Settings"
6. Click "Add custom domain"
7. Enter `jackmorello.com`
8. Follow Netlify's DNS instructions to point your domain

### Option 2: Vercel (Also Easy)
1. Go to https://vercel.com
2. Sign up/login
3. Click "Add New" → "Project"
4. Upload the `jackmorello-website` folder
5. Click "Deploy"
6. Go to project settings → Domains
7. Add `jackmorello.com`
8. Update your DNS as instructed

## Disconnect from Carrd

1. Log into Carrd
2. Go to your jackmorello.com site settings
3. Remove the custom domain
4. Cancel/downgrade your Carrd plan if you want

## Update DNS (at your domain registrar)

**If using Netlify:**
- Type: A Record
- Name: @ 
- Value: 75.2.60.5

- Type: CNAME
- Name: www
- Value: your-site.netlify.app

**If using Vercel:**
- Type: A Record
- Name: @
- Value: 76.76.21.21

- Type: CNAME
- Name: www
- Value: cname.vercel-dns.com

## Local Development (VS Code)

1. Download this folder
2. Open in VS Code
3. Install "Live Server" extension
4. Right-click `index.html` → "Open with Live Server"
5. Edit files, they auto-refresh in browser

## What's Included

- ✅ Space travel starfield background
- ✅ Infinite scrolling brand marquee
- ✅ Marketing Leadership section with company cards
- ✅ Paid Media grid with 9 major brands
- ✅ Creative platform showcase
- ✅ All 17 brand logos (separate image files)
- ✅ Fully responsive mobile design
- ✅ Clean typography with Inter font

## File Size
- Total: ~210KB
- Loads fast on all connections
- All images optimized

## Need Help?
The entire site is self-contained in this folder. Just upload it anywhere that serves static HTML and you're done.
